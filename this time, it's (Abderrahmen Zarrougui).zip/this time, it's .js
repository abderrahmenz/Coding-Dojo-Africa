const height = 42
const age = 11
if (height >= 42) {
    if (age > 10) {
        console.log("You can have a ride in the rollercoaster!");
    } else {
        console.log("Unfortunately, you are not old enough to ride.");
    }
} else {
    console.log("Sorry, your height does not match the requirments.");
}